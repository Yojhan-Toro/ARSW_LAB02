package edu.eci.arsw.primefinder;
import java.util.Scanner;

public class Control extends Thread {
    
    private final static int NTHREADS = 3;
    private final static int MAXVALUE = 30000000;
    public final static int TMILISECONDS = 5000;
    
    private final int NDATA = MAXVALUE / NTHREADS;
    private PrimeFinderThread pft[];
    private volatile boolean keepRunning = true;
    
    private Control() {
        super();
        this.pft = new PrimeFinderThread[NTHREADS];

        int i;
        for(i = 0; i < NTHREADS - 1; i++) {
            PrimeFinderThread elem = new PrimeFinderThread(i*NDATA, (i+1)*NDATA);
            pft[i] = elem;
        }
        pft[i] = new PrimeFinderThread(i*NDATA, MAXVALUE + 1);
    }
    
    public static Control newControl() {
        return new Control();
    }

    @Override
    public void run() {
        for(int i = 0; i < NTHREADS; i++) {
            pft[i].start();
        }

        while(keepRunning) {
            try {
                Thread.sleep(TMILISECONDS);
                pauseWorkers();
                printPrimes();
                waitForEnter();
                resumeWorkers();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void pauseWorkers() {
        for(int i = 0; i < NTHREADS; i++) {
            pft[i].pauseThread();
        }
    }

    private void resumeWorkers() {
        for(int i = 0; i < NTHREADS; i++) {
            pft[i].resumeThread();
        }
    }

    private void printPrimes() {
        for(int i = 0; i < NTHREADS; i++) {
            System.out.println("Primos encontrados por hilo " + i + ": " + pft[i].getPrimes().size());
        }
    }

    private void waitForEnter() {
        System.out.println("Presione ENTER para continuar...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
    }

    public void stopAll() {
        keepRunning = false;
        for(int i = 0; i < NTHREADS; i++) {
            pft[i].stopThread();
        }
    }
}